import setuptools
setuptools.setup(
    name='Frutas',
    version='11.0',
    description='Esto es una Fruteria',
    author='los pitones',
    author_email='Jesusdrc12@gmail.com',
    url='donpollo.web',
    packages=['packet'],
    scripts=[]
)